# proyecto-gradle

Plantilla de proyectos empleando Gradle y configurado con:

1. [Checkstyle](https://checkstyle.sourceforge.io/)
2. [PMD](https://pmd.github.io/)
3. [JACOCO](https://www.jacoco.org/jacoco/)

Las reglas empleadas estan en constante revisión, pero esta pensado para su uso
en la cátedra por lo que revisa una gran cantidad de detalles.

Esta [ReviewDog](https://github.com/reviewdog/reviewdog) en el repositorio pero desactivado.
