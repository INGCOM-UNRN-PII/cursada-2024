package ar.unrn;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;


/**
 * El nombre tiene que ser el mismo que la clase que testea
 * terminando con `Test` para funcionar.
 */
@DisplayName("Ejercicio 1")
class PlantillaAppTest {

    /**
     * Este test es una plantilla.
     */
    @Test
    @DisplayName("Completar que se esta probando")
    void testPlantilla() {
        ;//
    }
}
