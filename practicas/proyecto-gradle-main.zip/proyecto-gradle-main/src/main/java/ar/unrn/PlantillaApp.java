package ar.unrn;

/**
 * Esta es una plantilla de main.
 * Usen Shift+F6 sobre el nombre para cambiarlo al que necesiten.
 * ¡Esto lo pueden utilizar en cualquier identificador!
 * Acá va la consigna del ejercicio.
 */
public class PlantillaApp {

    /**
     * Punto de entrada del ejercicio.
     *
     * @param args son los argumentos de invocación.
     */
    public static void main(String[] args) {
        ;// Completar
    }
}
